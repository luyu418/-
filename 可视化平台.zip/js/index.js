/**
 * Created by Administrator on 2017/5/17.
 */
$(function(){
    // index();
    $(".index_nav ul li").each(function(index){
        $(this).click(function(){
            $(this).addClass("nav_active").siblings().removeClass("nav_active");
            $(".index_tabs .inner").eq(index).fadeIn().siblings("div").stop().hide();
            if(index==1){
                yingXiao();
            }else if(index==2){
                shouRu();
            }else if(index==3){
                AnQuan();
            }else if(index==4){
                user();
            }else if(index==5){
                manage();
            }
        })
    });
    $(".tabs ul li").each(function(index){
       $(this).click(function(){
           $(".tabs ul li div .div").removeClass("tabs_active");
           $(this).find("div .div").addClass("tabs_active");
           $(".tabs_map>div").eq(index).fadeIn().siblings("div").stop().hide();
       })
   });
    $(".middle_top_bot ul li").each(function(){
        $(this).click(function(){
            $(".middle_top_bot ul li").removeClass("middle_top_bot_active");
            $(this).addClass("middle_top_bot_active");
        })
    });

});
//统计分析3，隧道违规车辆分析
function user(){
//驾驶员年龄段分析
    $(function(){
        var myChart = echarts.init($("#container1")[0]);
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'left',
                y:"16",
                data: ['18-40', '41-65', '66-70'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    itemStyle: {
                        normal: {
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            }
                        }
                    },
                    name: '',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {
                            value:2840,
                            name:'18-40',
                            itemStyle:{
                                normal:{
                                    color:"#cbda77"
                                }
                            }
                        },
                        {
                            value:1390,
                            name:'41-65',
                            itemStyle:{
                                normal:{
                                    color:"#1afffd"
                                }
                            }
                        },
                        {
                            value:1095,
                            name:'66-70',
                            itemStyle:{
                                normal:{
                                    color:"#f56af5"
                                }
                            }
                        }
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });

//驾驶员性别分析
    $(function(){
        var myChart = echarts.init($("#container2")[0]);
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'left',
                y:"16",
                data: ['男性','女性'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    itemStyle: {
                        normal: {
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            }
                        }
                    },
                    name: '',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:3834, name:'男性',
                            itemStyle:{
                                normal:{
                                    color:"#2865aa"
                                }
                            }},
                        {value:1491, name:'女性',
                            itemStyle:{
                                normal:{
                                    color:"#ff81cb"
                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });

//违规类型分析
    $(function(){
        var myChart = echarts.init($("#container3")[0]);
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'right',
                y:"16",
                data: ['小汽车','客车','货车','其他'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    itemStyle: {
                        normal: {
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            }
                        }
                    },
                    name: '',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:2379, name:'小汽车',
                            itemStyle:{
                                normal:{
                                    color:"#45c0ff"
                                }
                            }},
                        {value:954, name:'客车',
                            itemStyle:{
                                normal:{
                                    color:"#e15828"
                                }
                            }},
                        {value:1362, name:'货车',
                            itemStyle:{
                                normal:{
                                    color:"#005ea1"
                                }
                            }},
                        {value:630, name:'其他',
                            itemStyle:{
                                normal:{
                                    color:"#2e7cff"
                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });

//违规车辆、男女分析
    $(function(){
        var myChart = echarts.init(document.getElementById('container4'));
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    data:['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            yAxis : [
                {
                    name:'/辆',
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'男性',
                    type:'bar',
                    stack: '',
                    barWidth:'30',
                    data:[320, 390, 358, 334, 360, 334, 320, 332, 301, 379, 332, 330],
                    itemStyle:{
                        normal:{
                            color:"#1afffd"
                        }
                    }
                },
                {
                    name:'女性',
                    type:'bar',
                    stack: '',
                    data:[90, 134, 102, 104, 120, 91, 110, 120, 82, 110, 82, 90],
                    /*[410, 524, 460, 438, 480, 425, 430, 452, 383, 489, 414, 420]*/
                    itemStyle:{
                        normal:{
                            color:"#2e7cff"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//车辆违规造成事故分析
    $(function(){
        var myChart = echarts.init(document.getElementById('container5'));
        var placeHoledStyle = {
            normal:{
                barBorderColor:'rgba(0,0,0,0)',
                color:'rgba(0,0,0,0)'
            },
            emphasis:{
                barBorderColor:'rgba(0,0,0,0)',
                color:'rgba(0,0,0,0)'
            }
        };
        var dataStyle = {
            normal: {
                label : {
                    show: true,
                    position: 'insideLeft',
                    formatter: '{c}%'
                }
            }
        };
        option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter : '{b}<br/>{a0}:{c0}<br/>{a2}:{c2}<br/>{a4}:{c4}<br/>{a6}:{c6}<br>{a8}:{c8}'
            },
            legend: {
                y: 55,
                data:['无事故', '轻微事故', '一般事故', '重大事故', '特大事故'],
                textStyle:{
                    color:"#fff"

                }
            },
            grid: {
                y: 80,
                y2: 30
            },
            xAxis : [
                {
                    type : 'value',
                    position: 'top',
                    splitLine: {show: false},
                    axisLabel: {show: false}
                }
            ],
            yAxis : [
                {
                    type : 'category',
                    splitLine: {show: false},
                    axisLabel : {
                        textStyle: {
                            color: '#fff',
                            align: 'right'
                        }
                    },
                    data : ['超速', '龟速', '随意变道', '闯禁令', '超车', '未开近光灯', '未系安全带']
                }
            ],
            series : [
                {
                    name:'无事故',
                    type:'bar',
                    stack: '总量',
                    data:[474, 158, 167, 155, 374, 283, 285],
                    itemStyle: {
                        normal: {
                            color:"#1afffd"
                        }
                    }
                },
                {
                    name:'无事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#2e7cff"
                        }
                    }
                },
                {
                    name:'轻微事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[416, 121, 287, 87, 318, 182, 137],
                    itemStyle: {
                        normal: {
                            color:"rgba(51,241,94,0.88)"
                        }
                    }
                },
                {
                    name:'轻微事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#005ea1"
                        }
                    }
                },
                {
                    name:'一般事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[286, 76, 210, 39, 158, 152, 95],
                    itemStyle: {
                        normal: {
                            color:"rgba(255,240,111,0.85)"
                        }
                    }
                },
                {
                    name:'一般事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#e15828"
                        }
                    }
                },
                {
                    name:'重大事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[178, 68, 108, 27, 97, 77, 55],
                    itemStyle: {
                        normal: {
                            color:"rgba(238,120,99,0.84)"
                        }
                    }
                },
                {
                    name:'重大事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#feb602"
                        }
                    }
                },
                {
                    name:'特大事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[139, 45, 142, 38, 74, 73, 28],
                    itemStyle: {
                        normal: {
                            color:"rgba(248,58,102,0.76)"
                        }
                    }
                },
                {
                    name:'特大事故',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#feb602"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//车辆违规地区分析
    $(function(){
        var myChart = echarts.init($("#container6")[0]);
        var option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : ['重庆市','江西省','福建省','湖北省','陕西省','山西省', '河南省','甘肃省','湖南省','浙江省','广东省','广西区','贵州省','辽宁省','新疆区', '四川省','宁夏区'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    name:'/辆',
                    type : 'bar',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'违规车辆',
                    type:'line',
                    stack: '',
                    data:[639, 278, 289, 346, 302, 342, 203, 336, 238, 272, 269, 304, 326, 344, 293, 258, 264],
                    itemStyle: {
                        normal: {
                            color:"rgba(255,174,245,0.82)"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//车辆违规时间段
    $(function(){
        var myChart = echarts.init($("#container9")[0]);
        var option = {
            tooltip: {   //提示框，鼠标悬浮交互时的信息提示
                show: true,
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            legend: {
                data: [],
                orient: 'vertical',
                textStyle: { fontWeight: 'bold', color: '#a4a7ab' }
            },
            calculable: true,
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: ['6:00-12:00', '12:00-14:00', '14:00-18:00', '18:00-23:00', '23:00-6:00'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis: [
                {
                    name:'/辆',
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    }
                }
            ],
            series: [
                {
                    name: '违规车辆',
                    type: 'line',
                    stack: '客流量',
                    data: [769, 1356, 785, 946, 1469],
                    itemStyle: {
                        normal: {
                            color: '#02bcbc'
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//违规行为分析
    $(function(){
        var myChart = echarts.init($("#container10")[0]);
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    data:['超速','龟速','随意变道','闯禁令','超车','未开近光灯','未系安全带'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    name:'/辆',
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'违规车辆',
                    type:'bar',
                    barWidth:'30',
                    data:[1493, 468, 630, 346, 1021, 767, 600],
                    itemStyle: {
                        normal: {
                            color:"rgba(248,58,102,0.8)"
                        }
                    }
                }

            ]
        };
        myChart.setOption(option);
    });

//违规车辆每月统计
    $(function(){
        var myChart = echarts.init(document.getElementById('container11'));
        var option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    name:'/辆',
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'违规车辆',
                    type:'line',
                    stack: '',
                    data:[410, 524, 460, 438, 480, 425, 430, 452, 383, 489, 414, 420],
                    itemStyle: {
                        normal: {
                            color:"#33f15e"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//违规车辆按年分析
    $(function(){
        var myChart = echarts.init($("#container12")[0]);
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            xAxis:  {
                name:'/辆',
                type: 'value',
                x:'180',
                splitLine: {
                    show: false
                },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a4a7ab'
                    }
                }
            },
            yAxis: {
                type: 'category',
                data: ['2015','2016','2017','2018','2019','2020','2021'],
                splitLine: {
                    show: false
                },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a4a7ab'
                    }
                }
            },
            series: [
                {
                    name: '违规车辆',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: true,
                            position: 'insideRight'
                        }
                    },
                    data: [4507, 5374, 4955, 3129, 5941, 3366, 6642],
                    itemStyle: {
                        normal: {
                            color:"#ff7d0a"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

}

//统计分析，公路里程分析（已删除）
function manage(){
//里程分析统计
    $(function(){
        var myChart = echarts.init($("#userContainerPersonal")[0]);
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            xAxis:  {
                type: 'value',
                x:'180',
                splitLine: {
                    show: false
                },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a4a7ab'
                    }
                }
            },
            yAxis: {
                type: 'category',
                data: ['北京','天津','河北','山西','内蒙古'],
                splitLine: {
                    show: false
                },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a4a7ab'
                    }
                }
            },
            series: [
                {
                    name: '公路里程（公里）',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: true,
                            position: 'insideRight'
                        }
                    },
                    data: [22320, 15302, 207170, 144617, 212603],
                    itemStyle: {
                        normal: {
                            color:"#45c0ff"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//收入分析统计
    $(function(){
        var myChart = echarts.init(document.getElementById('userContainerFlow'));
        var option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : ['上海','江苏','浙江','安徽','福建','江西','山东'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }

                }
            ],
            series : [
                {
                    name:'公路里程（公里）',
                    type:'line',
                    stack: '总量',
                    data:[13082, 158036, 123885, 237411, 111031, 211101, 288123],
                    itemStyle: {
                        normal: {
                            color:"#1afffd"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//支出分析统计
    $(function(){
        var myChart = echarts.init($("#userContainerIllegal")[0]);
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    data:['重庆', '四川', '贵州', '云南', '西藏'],

                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'公路里程（公里）',
                    type:'bar',
                    barWidth:'30',
                    data:[184106, 398899, 207190, 300890, 120132],
                    itemStyle: {
                        normal: {
                            color:"#269fec"
                        }
                    }

                }
            ]
        };
        myChart.setOption(option);
    });

//饼状图1
    $(function(){
        var myChart = echarts.init($("#userContainerSex")[0]);
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'left',
                y:"16",
                data: ['等级公路','等外公路'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    itemStyle: {
                        normal: {
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            }
                        }
                    },
                    name: '',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:5061899, name:'等级公路',
                            itemStyle:{
                                normal:{
                                    color:"#2865aa"
                                }
                            }},
                        {value:218809, name:'等外公路',
                            itemStyle:{
                                normal:{
                                    color:"#ff81cb"
                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });

//饼状图2
    $(function(){
        var myChart = echarts.init($("#userContainerManage")[0]);
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                x: 'center',
                y:"16",
                data:['高速公路', '一级公路', '二级公路', '其他等级公路'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    itemStyle: {
                        normal: {
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            }
                        }
                    },
                    name: '',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {
                            value:169071,
                            name:'高速公路',
                            itemStyle:{
                                normal:{
                                    color:"#1afffd"
                                }
                            }
                        },
                        {
                            value:128162,
                            name:'一级公路',
                            itemStyle:{
                                normal:{
                                    color:"#2e7cff"
                                }
                            }
                        },
                        {
                            value:426417,
                            name:'二级公路',
                            itemStyle:{
                                normal:{
                                    color:"#ffcb89"
                                }
                            }
                        }
                        ,
                        {
                            value:4338249,
                            name:'其他等级公路',
                            itemStyle:{
                                normal:{
                                    color:"#005ea1"
                                }
                            }
                        }
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });

//饼状图3
    $(function(){
        var myChart = echarts.init($("#userContainerAge")[0]);
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'right',
                y:"16",
                data: ['高速公路', '一级公路', '二级公路', '其他等级公路','等外公路'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    itemStyle: {
                        normal: {
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            }
                        }
                    },
                    name: '',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:169071, name:'高速公路',
                            itemStyle:{
                                normal:{
                                    color:"#0ad5ff"
                                }
                            }},
                        {value:128162, name:'一级公路',
                            itemStyle:{
                                normal:{
                                    color:"#005ea1"
                                }
                            }},
                        {value:426417, name:'二级公路',
                            itemStyle:{
                                normal:{
                                    color:"#ffcb89"
                                }
                            }},
                        {value:4338249, name:'其他等级公路',
                            itemStyle:{
                                normal:{
                                    color:"#2e7cff"
                                }
                            }},
                        {value:218809, name:'等外公路',
                            itemStyle:{
                                normal:{
                                    color:"#1afffd"
                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });

//华南地区
    $(function(){
        var myChart = echarts.init($("#userContainerAttendance")[0]);
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    data:['河南', '湖北', '湖南', '广东', '广西', '海南'],

                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'公路里程（公里）',
                    type:'bar',
                    barWidth:'30',
                    data:[271570, 296922, 241940, 222987, 160637, 41046],
                    itemStyle: {
                        normal: {
                            color:"#1afffd"
                        }
                    }

                }
            ]
        };
        myChart.setOption(option);
    });

//西北地区
    $(function(){
        var myChart = echarts.init(document.getElementById('userContainerComplaint'));
        var option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            calculable : true,
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : ['陕西','甘肃','青海','宁夏','新疆'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }

                }
            ],
            series : [
                {
                    name:'公路里程（公里）',
                    type:'line',
                    stack: '总量',
                    data:[183414, 156583, 86152, 37577, 217326],
                    itemStyle: {
                        normal: {
                            color:"#45c0ff"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//东北地区
    $(function(){
        var myChart = echarts.init(document.getElementById('userContainerPrize'));
        var option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                x: 46,
                y:30,
                x2:32,
                y2:40,
                borderWidth: 0
            },
            xAxis : [
                {
                    type : 'category',
                    data : ['辽宁', '吉林', '黑龙江'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'公路里程（公里）',
                    type:'bar',
                    data:[131588, 108691, 168354],
                    itemStyle:{
                        normal:{
                            color:"#1afffd"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//北部地区对比，右1饼状图
    $(function(){
        var myChart = echarts.init(document.getElementById('userContainerReason'));
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'left',
                data: ['华北地区','东北地区','西北地区'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    name: '公路里程（公里）',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:602012, name:'华北地区',
                            itemStyle:{
                                normal:{
                                    color:"#1aff40"
                                }
                            }},
                        {value:408633, name:'东北地区',
                            itemStyle:{
                                normal:{
                                    color:"#fff06f"
                                }
                            }},
                        {value:681052, name:'西北地区',
                            itemStyle:{
                                normal:{
                                    color:"#fd99fd"
                                }
                            }}
                    ],
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

//东、南部地区，右2饼状图
    $(function(){
        var myChart = echarts.init(document.getElementById('userContainerHandle'));
        var option = {
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                x: 'right',
                data: ['华南地区','西南地区','华东地区'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            series : [
                {
                    name: '公路里程（公里）',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:1235102, name:'华南地区',
                            itemStyle:{
                                normal:{
                                    color:"#2e7cff"
                                }
                            }},
                        {value:1211217, name:'西南地区',
                            itemStyle:{
                                normal:{
                                    color:"#ffcb89"
                                }
                            }},
                        {value:1142669, name:'华东地区',
                            itemStyle:{
                                normal:{
                                    color:"#2864ab"
                                }
                            }}
                    ],
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
}

// 统计分析1页面，公路隧道分析
function yingXiao(){
// 最长隧道年表
    $(function(){
        var myChart = echarts.init($("#buyTime")[0]);
        var option = {
            tooltip: {   //提示框，鼠标悬浮交互时的信息提示
                show: true,
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:40,
                borderWidth: 0
            },
            legend: {
                data: [],
                orient: 'vertical',
                textStyle: { fontWeight: 'bold', color: '#a4a7ab' }
            },

            calculable: false,
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: [`1969-1971 愚公洞`,
                        `1971-1987 打浦路隧道`,
                        `1987-1993 鼓山隧道`,
                        `1993-1998 云台山隧道`,
                        `1998-1999 大溪岭隧道`,
                        `1999-2000 二郎山隧道`,
                        `2000-2003 华蓥山隧道`,
                        `2003-2004 雁门关隧道`,
                        `2004-2006 美菰林隧道`,
                        `2006-2007 方斗山隧道`,
                        `2007-至今 秦岭终南山隧道`],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }

            ],
            yAxis: [
                {
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    }
                }
            ],
            series: [
                {
                    name: '长度(米)',
                    type: 'line',
                    stack: '',
                    data: [810, 2736, 3138.4, 3641, 4116, 4176, 4706, 5235, 5580, 7605, 18020],
                    itemStyle: {
                        normal: {
                            color: '#02bcbc'
                        }
                    }
                }
            ]
        };

        myChart.setOption(option);
    });
// 各省份隧道数量分类统计
    $(function(){
        var myChart = echarts.init($("#Package01")[0]);
        var option = {
            tooltip: {   //提示框，鼠标悬浮交互时的信息提示
                show: true,
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:40,
                borderWidth: 0
            },
            legend: {
                data: [],
                orient: 'vertical',
                textStyle: { fontWeight: 'bold', color: '#a4a7ab' }
            },

            calculable: false,
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: ['重庆市','江西省','福建省','湖北省','陕西省','山西省', '河南省','甘肃省','湖南省','浙江省','广东省','广西区','贵州省','辽宁省','新疆区', '四川省','宁夏区'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'red'
                        }
                    }
                }
            ],
            series: [
                {
                    name: '数量(处)',
                    type: 'line',
                    stack: '',
                    data: [30, 2, 2, 5, 5, 2, 1, 1, 1, 1, 3, 1, 6, 1, 1, 1,2],
                    itemStyle: {
                        normal: {
                            color: 'green'
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 隧道长度分类统计
    $(function(){
        var myChart = echarts.init($("#rode01")[0]);
        option = {
            legend: {
                orient : 'vertical',
                x : 'left',
                data:['特长隧道','长隧道','中隧道','短隧道'], textStyle:{
                    color:"#e9ebee"
                }
            },
            calculable : false,
            series : [
                {
                    name:'面积模式',
                    type:'pie',
                    radius : '60%',
                    center: ['50%', '60%'],
                    roseType : 'area',
                    x: '50%',               // for funnel
                    max: 40,                // for funnel
                    sort : 'ascending',     // for funnel
                    data:[
                        {value:31, name:'特长隧道',
                            itemStyle: {
                                normal: {
                                    color:"#45c0ff"
                                }
                            }},
                        {value:11, name:'长隧道',
                            itemStyle: {
                                normal: {
                                    color:"#e15828"
                                }
                            }},
                        {value:7, name:'中隧道',
                            itemStyle: {
                                normal: {
                                    color:"#ff81cb"
                                }
                            }},
                        {value:1, name:'短隧道',
                            itemStyle: {
                                normal: {
                                    color:"#2e7cff"
                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });
// 公路隧道数量
    $(function(){
        var myChart = echarts.init($("#bookAret")[0]);
        option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:40,
                borderWidth: 0
            },
            calculable : false,
            xAxis : [
                {
                    type : 'category',
                    data : ['2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'],
                    axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#a4a7ab',
                        align: 'center'
                    },
                    splitLine: {
                        show: false
                    },
                }
                }
            ],
            yAxis : [
                {
                    name:'/处',
                    type : 'value',
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine: {
                        show: false
                    },
                }
            ],
            series : [
                {
                    name:'隧道数量',
                    type:'bar',
                    data:[7284, 8522, 10022, 11359, 12404, 14006, 15181, 16229, 17738, 19067, 21316],
                    markLine : {
                        data : [
                            {type : 'average', name : '平均值'}
                        ]
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 公路隧道数量和长度增长
    $(function(){
        var myChart = echarts.init($("#bookBmonth")[0]);
        var option = {
            tooltip: {   //提示框，鼠标悬浮交互时的信息提示
                show: true,
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:40,
                borderWidth: 0
            },
            legend: {
                data: [],
                orient: 'vertical',
                textStyle: { fontWeight: 'bold', color: '#a4a7ab' }
            },
            calculable: false,
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data : ['2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis: [
                {
                    name:'增长量',
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    }
                }
            ],
            series: [
                {
                    name: '隧道数量（处）',
                    type: 'line',
                    stack: '',
                    data:[1238, 1500, 1337, 1045, 1602, 1175, 1048, 1509, 1329, 2249],
                    itemStyle: {
                        normal: {
                            color: '#33f15e'
                        }
                    }
                },
                {
                    name: '隧道长度（米）',
                    type: 'line',
                    stack: '',
                    data:[1129, 1800, 1554, 971, 2107, 1355, 1246, 1951, 1731, 3032],
                    itemStyle: {
                        normal: {
                            color: '#f83a66'
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 公路隧道长度
    $(function(){
        var myChart = echarts.init($("#whearAbook")[0]);
        option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:20,
                borderWidth: 0
            },

            calculable : false,
            xAxis : [
                {
                    type : 'category',
                    data : ['2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }

                }
            ],
            yAxis : [
                {
                    type : 'value',
                    name : '/千米',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine: {
                        show: false
                    },
                }
            ],
            series : [

                {
                    name:'隧道长度',
                    type:'bar',
                    data:[5123, 6252, 8052, 9606, 10577, 12684, 14039, 15285, 17236, 18967, 21999],
                    itemStyle: {
                        normal: {
                            color:"#0ad5ff"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 公路隧道和特长隧道、长隧道的数量及长度
    $(function(){
        var myChart = echarts.init($("#rodeAbook")[0]);
        option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:20,
                borderWidth: 0
            },
            xAxis : [
                {
                    type : 'category',
                    data : ['公路隧道','特长隧道','长隧道'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }

                }
            ],
            yAxis : [
                {
                    type : 'value',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine: {
                        show: false
                    },
                },
                {
                    type : 'value',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine: {
                        show: false
                    },
                },

            ],
            series : [
                {
                    name:'隧道数量（处）',
                    type:'bar',
                    yAxisIndex: 1,
                    data:[21316,1394,6211],
                    itemStyle: {
                        normal: {
                            color:"#0ad5ff"
                        }
                    }
                },
                {
                    name: '隧道长度（千米）',
                    type:'bar',
                    stack: '车流量',
                    data: [21999,6236,10844.3],
                    itemStyle: {
                        normal: {
                            color:"#ffcb89"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 特长隧道数量
    $(function(){
        var myChart = echarts.init($("#seaAbook01")[0]);
        option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:20,
                borderWidth: 0
            },

            calculable : false,
            xAxis : [
                {
                    type : 'category',
                    data : ['2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }

                }
            ],
            yAxis : [
                {
                    type : 'value',

                    name : '/处',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine: {
                        show: false
                    },
                }
            ],
            series : [

                {
                    name:'特长隧道数量',
                    type:'bar',
                    data:[265, 326, 441, 562, 626, 744, 815, 902, 1058, 1175, 1394],
                    itemStyle: {
                        normal: {
                            color:"#ffaef5"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 特长隧道数量和长度增长
    $(function(){
        var myChart = echarts.init($("#actionBook")[0]);
        var option = {
            tooltip: {   //提示框，鼠标悬浮交互时的信息提示
                show: true,
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:40,
                borderWidth: 0
            },
            legend: {
                data: [],
                orient: 'vertical',
                textStyle: { fontWeight: 'bold', color: '#a4a7ab' }
            },

            calculable: false,
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data : ['2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis: [
                {
                    name:'增长量',
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    }
                }
            ],
            series: [
                {
                    name: '隧道数量（处）',
                    type: 'line',
                    stack: '',
                    data:[61, 115, 123, 64, 118, 71, 87, 156, 117, 119],
                    itemStyle: {
                        normal: {
                            color: 'purple'
                        }
                    }
                },
                {
                    name: '隧道长度（米）',
                    type: 'line',
                    stack: '',
                    data:[295, 552, 522, 259, 534, 323, 390, 594, 511, 1018],
                    itemStyle: {
                        normal: {
                            color: 'gray'
                        }
                    }
                }
            ]
        };

        myChart.setOption(option);
    });
// 特长隧道长度
    $(function(){
        var myChart = echarts.init($("#sperceBook01")[0]);
        option = {
            tooltip : {
                trigger: 'axis'
            },
            grid: {
                x: 46,
                y:30,
                x2:30,
                y2:20,
                borderWidth: 0
            },

            calculable : false,

            xAxis : [
                {
                    type : 'category',
                    data : ['2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'],
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'center'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',

                    name : '/千米',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine: {
                        show: false
                    },
                }
            ],
            series : [

                {
                    name:'特长隧道长度',
                    type:'bar',
                    data:[1138, 1433, 1985, 2507, 2766, 3300, 3623, 4013, 4707, 5218, 6236],
                    itemStyle: {
                        normal: {
                            color:"#2b81e3"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });

}

// 收入支出分析，统计分析2页面
function shouRu(){
// 收入渠道分析
    $(function(){
        var myChart = echarts.init($("#zhanbi02")[0]);
        var option = {

            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
                }
            },
            grid:{
              borderWidth:0
            },
            xAxis : [
                {
                    type : 'category',
                    data : ['总收入','广告收入','通行费收入'],
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine:{show: false}
                }
            ],
            yAxis : [
                {
                    name:'/亿元',
                    type : 'value',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine:{show: false}
                }
            ],
            series : [
                {
                    name:'总收入',
                    type:'bar',
                    stack: '总量',
                    itemStyle:{
                        normal:{
                            barBorderColor:'rgba(0,0,0,0)',
                            color:'rgba(0,0,0,0)'
                        },
                        emphasis:{
                            barBorderColor:'rgba(0,0,0,0)',
                            color:'rgba(0,0,0,0)'
                        }
                    },
                    data:[0, 13.2, 0]
                },
                {
                    name:'收入',
                    type:'bar',
                    stack: '总量',
                    data:[33, 19.8, 13.2],
                    itemStyle: {
                        normal: {
                            color: '#2481ff'
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 支出渠道分析
    $(function(){
        var myChart = echarts.init($("#zhanbi03")[0]);
        option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter: function (params) {
                    var tar = params[0];
                    return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
                }
            },
            xAxis : [
                {
                    type : 'category',
                    splitLine: {show:false},
                    data : ['总收入','修建支出','能源消耗支出','维护支出','利润'],
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine:{show: false}
                }
            ],
            grid:{
                borderWidth:0
            },
            yAxis : [
                {
                    name:'/亿元',
                    type : 'value',
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    splitLine:{show: false}
                }
            ],
            series : [
                {
                    name:'总收入',
                    type:'bar',
                    stack: '总量',
                    itemStyle: {
                        normal: {
                            color: '#1afffd'
                        }
                    },
                    data:[0, 1.07, 0.77, 0.37, 0]
                },
                {
                    name:'支出',
                    type:'bar',
                    stack: '总量',
                    itemStyle:{
                        normal:{
                                color:'#28a3e1'

                        }
                    },
                    data:[33, 31.93, 0.3, 0.4, 0.37]
                }
            ]
        };
        myChart.setOption(option);
    });
// 营销投入与销售量分析
    $(function(){
        var myChart = echarts.init($("#allAly01")[0]);
        option = {
            title : {
                text: '收入组成',
                textStyle:{
                    color:"#e9ebee"
                },
                x:'center'
            },
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient : 'vertical',
                x : 'left',
                data:['广告收入','通行费收入'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            calculable : false,
            series : [
                {
                    name:'收入组成',
                    type:'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:19.8, name:'广告收入',
                            itemStyle:{
                                normal:{
                                    color:'#1afffd'

                                }
                            }
                        },
                        {value:13.2, name:'通行费收入',
                            itemStyle:{
                                normal:{
                                    color:'#2e7cff'

                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });
    $(function(){
        var myChart = echarts.init($("#allAly02")[0]);
        option = {
            title : {
                text: '支出组成',
                textStyle:{
                    color:"#e9ebee"

                },
                x:'center'
            },
            tooltip : {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            legend: {
                orient : 'vertical',
                x : 'left',
                data:['修建指出','能源消耗支出','维护支出'],
                textStyle:{
                    color:"#e9ebee"
                }
            },
            calculable : false,
            series : [
                {
                    name:'支出组成',
                    type:'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                        {value:31.93, name:'修建支出',
                            itemStyle:{
                                normal:{
                                    color:'#06b8f8'

                                }
                            }},
                        {value:0.3, name:'能源消耗',
                            itemStyle:{
                                normal:{
                                    color:'#ff5c58'

                                }
                            }},
                        {value:0.4, name:'维护支出',
                            itemStyle:{
                                normal:{
                                    color:'#ffffb3'

                                }
                            }}
                    ]
                }
            ]
        };
        myChart.setOption(option);
    });
    $(function(){
        var myChart = echarts.init($("#allAly03")[0]);
        option = {
            title : {
                text: '收入与支出分析',
                textStyle:{
                    color:"#e9ebee"
                },
                x:'center'
            },
            tooltip : {
                trigger: 'axis'
            },
            legend: {
                orient : 'vertical',
                x : 'left',
                data:['支出','收入'],
                textStyle:{
                    color:"#e9ebee"
                },
            },
            calculable : false,
            xAxis : [
                {
                    type : 'category',
                    splitLine:{show: false},
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
                }
            ],
            yAxis : [
                {
                    name:'/亿元',
                    type : 'value',
                    splitLine:{show: false},
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    }
                }
            ],
            grid:{
                borderWidth:0
            },
            series : [
                {
                    name:'支出',
                    type:'bar',
                    data:[5.56, 4.9, 5.27, 5.3, 4.63, 4.8, 0.64, 0.23, 0.25, 0.35, 0.4, 0.3],
                    itemStyle: {
                        normal: {
                            color: '#2481ff'
                        }
                    },
                    markPoint : {
                        data : [
                            {type : 'max', name: '最大值'},
                            {type : 'min', name: '最小值'}
                        ]
                    },
                    markLine : {
                        data : [
                            {type : 'average', name: '平均值'}
                        ]
                    }
                },
                {
                    name:'收入',
                    type:'bar',
                    data:[0, 0, 0, 0, 0, 0, 6.3, 5.2, 6.7, 5.8, 5.0, 4],
                    itemStyle: {
                        normal: {
                            color: '#1afffd'
                        }
                    },

                    markPoint : {
                        data : [
                            {name : '最高', value : 6.7, xAxis: 8, yAxis: 7, symbolSize:18},
                            {name : '最低', value : 0, xAxis: 1, yAxis: 0}
                        ]
                    },
                    markLine : {
                        data : [
                            {type : 'average', name : '平均值'}
                        ]
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
}

//统计分析4页面，隧道车流量分析
function AnQuan(){
// 隧道车流量统计
    $(function(){
        var myChart = echarts.init($("#shijian01")[0]);
        option = {

            tooltip: {
                trigger: "item",
                formatter: "{a} <br/>{b} : {c}"
            },
            xAxis: [
                {
                    type: "category",
                    name: "时间",
                    splitLine:{show: false},
                    axisLabel : {
                        formatter: '{value} ',
                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                    data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
                }
            ],
            grid:{
                borderWidth:0
            },
            yAxis: [
                {
                    type: "log",
                    name: "/万辆",
                    splitLine:{show: false},
                    data : ['500','600','700','800','900','1000','1100','1200','1300','1400','1500','1600','1700'],
                    axisLabel : {

                        textStyle: {
                            color: '#a4a7ab',
                            align: 'right'
                        }
                    },
                }
            ],
            calculable: false,
            series: [
                {
                    name: "车流量",
                    type: "line",
                    data:[1079, 1294, 980, 926, 828, 670, 975, 682, 748, 688, 760, 523],
                    itemStyle: {
                        normal: {
                            color:"#0aabff"
                        }
                    }

                }

            ]
        };
        myChart.setOption(option);
    });
// 隧道车辆分布，举例分析
    $(function(){
        var myChart = echarts.init($("#shijian02")[0]);
        var placeHoledStyle = {
            normal:{
                barBorderColor:'rgba(0,0,0,0)',
                color:'rgba(0,0,0,0)'
            },
            emphasis:{
                barBorderColor:'rgba(0,0,0,0)',
                color:'rgba(0,0,0,0)'
            }
        };
        var dataStyle = {
            normal: {
                label : {
                    show: true,
                    position: 'insideLeft',
                    formatter: '{c}%'
                }
            }
        };
        option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter : '{b}<br/>{a0}:{c0}%<br/>{a2}:{c2}%<br/>{a4}:{c4}%<br/>{a6}:{c6}%<br>{a8}:{c8}%'
            },
            legend: {
                y: 55,
                data:['小汽车', '货车','客车', '救援车', '其他'],
                textStyle:{
                    color:"#fff"

                }
            },
            grid: {
                y: 80,
                y2: 30
            },
            xAxis : [
                {
                    type : 'value',
                    position: 'top',
                    splitLine: {show: false},
                    axisLabel: {show: false}
                }
            ],
            yAxis : [
                {
                    type : 'category',
                    splitLine: {show: false},
                    axisLabel : {

                        textStyle: {
                            color: '#fff',
                            align: 'right'
                        }
                    },
                    data : ['中梁山隧道', '龙井关隧道', '玉峰山隧道', '长滩隧道']
                }
            ],
            series : [
                {
                    name:'小汽车',
                    type:'bar',
                    stack: '总量',
                    data:[55, 58, 67, 55],
                    itemStyle: {
                        normal: {
                            color:"#1afffd"
                        }
                    }
                },
                {
                    name:'小汽车',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#2e7cff"
                        }
                    }
                },
                {
                    name:'货车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[27, 21, 17, 27],
                    itemStyle: {
                        normal: {
                            color:"#ffcb89"
                        }
                    }
                },
                {
                    name:'货车',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#005ea1"
                        }
                    }
                },
                {
                    name:'客车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[15, 16, 10, 13],
                    itemStyle: {
                        normal: {
                            color:"#0ad5ff"
                        }
                    }
                },
                {
                    name:'客车',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#e15828"
                        }
                    }
                },
                {
                    name:'救援车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[2.9, 4.5, 5.8, 4.7],
                    itemStyle: {
                        normal: {
                            color:"#ff81cb"
                        }
                    }
                },
                {
                    name:'救援车',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#feb602"
                        }
                    }
                },
                {
                    name:'其他',
                    type:'bar',
                    stack: '总量',
                    itemStyle : dataStyle,
                    data:[0.1, 0.5, 0.2, 0.3],
                    itemStyle: {
                        normal: {
                            color:"#1aff40"
                        }
                    }
                },
                {
                    name:'其他',
                    type:'bar',
                    stack: '总量',
                    itemStyle: placeHoledStyle,
                    data:[0, 0, 0, 0],
                    itemStyle: {
                        normal: {
                            color:"#feb602"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 车辆类型分析，总的车流量
    $(function(){
        var myChart = echarts.init($("#shijian03")[0]);
        var labelTop = {
            normal : {
                label : {
                    show : true,
                    position : 'center',
                    formatter : '{b}',
                    textStyle: {
                        baseline : 'bottom'
                    }
                },
                labelLine : {
                    show : false
                }
            }
        };
        var labelFromatter = {
            normal : {
                label : {
                    formatter : function (params){
                        return 100 - params.value + '%'
                    },
                    textStyle: {
                        baseline : 'top'
                    }
                }
            },
        }
        var labelBottom = {
            normal : {
                color: '#111b21',
                label : {
                    show : true,
                    position : 'center'
                },
                labelLine : {
                    show : false
                }
            },
            emphasis: {
                color: 'rgba(0,0,0,0)'
            }
        };
        var radius = [40, 55];
        option = {
            legend: {
                x : 'center',
                textStyle:{
                    color:"#fff"
                },
                data:[
                    '小汽车','货车','客车','救援车','其它'
                ]
            },
            series : [
                {
                    type : 'pie',
                    center : ['10%', '30%'],
                    radius : radius,
                    x: '0%', // for funnel
                    itemStyle : labelFromatter,
                    data : [
                        {name:'', value:50, itemStyle : labelBottom},
                        {name:'小汽车', value:50,itemStyle : labelTop}
                    ],
                    itemStyle: {
                        normal: {
                            color:"#0ad5ff"
                        }
                    }
                },
                {
                    type : 'pie',
                    center : ['30%', '30%'],
                    radius : radius,
                    x:'20%', // for funnel
                    itemStyle : labelFromatter,
                    data : [
                        {name:'', value:73, itemStyle : labelBottom},
                        {name:'货车', value:27,itemStyle : labelTop}
                    ],
                    itemStyle: {
                        normal: {
                            color:"#ffcb89"
                        }
                    }
                },
                {
                    type : 'pie',
                    center : ['50%', '30%'],
                    radius : radius,
                    x:'40%', // for funnel
                    itemStyle : labelFromatter,
                    data : [
                        {name:'', value:80, itemStyle : labelBottom},
                        {name:'客车', value:20,itemStyle : labelTop}
                    ],
                    itemStyle: {
                        normal: {
                            color:"#2e7cff"
                        }
                    }
                },
                {
                    type : 'pie',
                    center : ['70%', '30%'],
                    radius : radius,
                    x:'60%', // for funnel
                    itemStyle : labelFromatter,
                    data : [
                        {name:'', value:97.2, itemStyle : labelBottom},
                        {name:'救援车', value:2.8,itemStyle : labelTop}

                    ],
                    itemStyle: {
                        normal: {
                            color:"#4cffd3"
                        }
                    }
                },
                {
                    type : 'pie',
                    center : ['90%', '30%'],
                    radius : radius,
                    // for funnel
                    x:'80%', // for funnel
                    itemStyle : labelFromatter,
                    data : [
                        {name:'', value:99.8, itemStyle : labelBottom},
                        {name:'其它', value:0.2,itemStyle : labelTop}
                    ],
                    itemStyle: {
                        normal: {
                            color:"#feb602"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
// 车辆流量分析
    $(function(){
        var myChart = echarts.init($("#shijian04")[0]);
        option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            legend: {
                data:['小汽车', '货车','客车','救援车','其它'],
                textStyle:{
                    color:"#fff"

                },
            },
            calculable : false,
            xAxis : [
                {
                    name:'/辆',
                    type : 'value',
                    splitLine: {show: false},
                    axisLabel : {

                        textStyle: {
                            color: '#fff',
                            align: 'right'
                        }
                    },
                }
            ],
            yAxis : [
                {
                    name:'/日',
                    type : 'category',
                    splitLine: {show: false},
                    axisLabel : {

                        textStyle: {
                            color: '#fff',
                            align: 'right'
                        }
                    },
                    data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12','13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24','25','26','27','28','29','30']
                }
            ],
            series : [
                {
                    name:'小汽车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                    data: [1290, 1383, 1160, 1176, 1269, 1203, 1201, 1163, 1208, 1206, 1197, 1180, 1192, 1172, 1311, 1414, 1219, 1323, 1221, 1320, 1120, 1325, 1028, 1130, 1209, 1302, 1283, 1238, 1289, 1098]
                    ,
                    itemStyle: {
                        normal: {
                            color:"#fff06f"
                        }
                    }
                },
                {
                    name:'货车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                    data: [710, 813, 620, 716, 719, 623, 821, 723, 920, 726, 827, 930, 712, 712, 611, 814, 619, 623, 721, 620, 800, 725, 680, 730, 748, 845, 730, 823, 794, 900]
                    ,
                    itemStyle: {
                        normal: {
                            color:"#3dc3f6"
                        }
                    }
                },
                {
                    name:'客车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                    data: [312, 213, 310, 216, 279, 302, 285, 283, 300, 276, 299, 230, 212, 272, 261, 294, 261, 303, 301, 320, 270, 245, 202, 290, 251, 249, 300, 285, 252, 270]
                    ,
                    itemStyle: {
                        normal: {
                            color:"#33f15e"
                        }
                    }
                },
                {
                    name:'救援车',
                    type:'bar',
                    stack: '总量',
                    itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                    data: [42, 33, 20, 36, 29, 23, 21, 23, 20, 26, 27, 30, 19, 12, 31, 24, 19, 23, 21, 20, 20, 15, 28, 20, 21, 30, 20, 25, 28, 20]
                    ,
                    itemStyle: {
                        normal: {
                            color:"#f56af5"
                        }
                    }
                },
                {
                    name:'其它',
                    type:'bar',
                    stack: '总量',
                    itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                    data: [4, 3, 10, 6, 9, 3, 11, 3, 10, 6, 7, 13, 2, 2, 9, 4, 9, 3, 4, 6, 4, 5, 8, 3, 5, 5, 9, 5, 8, 3]
                    ,
                    itemStyle: {
                        normal: {
                            color:"#1afffd"
                        }
                    }
                }
            ]
        };
        myChart.setOption(option);
    });
}
